# Code scrollbar paints over the floating table of contents

Minimal reproduction for the Modern theme with `pymdownx-inline` line numbers.

## Run

Use an existing Zensical environment, or install the recorded environment with `python -m pip install -r requirements.txt`. Then run:

```console
python -m zensical serve
```

Open http://127.0.0.1:8000/ in the browser. `python -m zensical build --clean --strict` also succeeds.

## Environment

- Zensical 0.0.74; Zensical UI 0.0.41
- Python 3.11.15
- Windows build 10.0.26200, x86_64
- Microsoft Edge 156.0.4314.58 (Chromium)
- Viewport: 432 x 850 CSS pixels, device scale factor 1
- Fresh temporary browser profile, extensions disabled

`requirements.txt` records the existing installed packages. No custom CSS, JavaScript, template overrides or additional plugins are required. The repeated paragraphs only provide vertical scroll space; the sample URLs are not fetched.

## Reproduce

1. Enable mobile device emulation, including mobile rendering and touch input, at 432 x 850; refresh.
2. Scroll until the code sample is in the lower half of the screen.
3. Open the floating table of contents using the bottom-right button.
4. Position the code sample so its bottom scrollbar overlaps the open table of contents.
5. Swipe horizontally in the exposed left side of the code sample.

Observed: the gray horizontal scrollbar crosses the white floating panel and its text, while the code text is correctly covered. Expected: the panel covers the entire code block, including its scrollbar.

At the same viewport dimensions, desktop rendering covers the scrollbar correctly. In earlier control tests, no line numbers or `linenums_style = "table"` also behaved correctly. Narrowing a desktop window alone does not enable mobile rendering.

The issue was confirmed in Chromium mobile emulation. A similar symptom was reported on a physical phone, but its browser/device details have not been independently verified.
