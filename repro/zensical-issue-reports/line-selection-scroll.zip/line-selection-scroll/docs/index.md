# Code block reproduction

## Page content

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

## Code sample

```bash
Server = https://example.invalid/packages/mingw/very-long-path-to-force-horizontal-overflow-on-a-mobile-screen/$repo/
Server = https://example.invalid/packages/mingw/another-long-path-to-force-horizontal-overflow-on-a-mobile-screen/$repo/
Server = https://example.invalid/packages/mingw/third-long-path-to-force-horizontal-overflow-on-a-mobile-screen/$repo/
```

## Additional section A

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

## Additional section B

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

## Additional section C

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.

This paragraph provides enough vertical content to scroll the page. It is ordinary Markdown and has no custom styling. Keep the code sample in the lower half of the viewport when testing the floating table of contents.
