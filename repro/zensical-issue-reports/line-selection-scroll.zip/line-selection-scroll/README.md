# Selecting a visible code line scrolls it behind the fixed header

Minimal reproduction using the default Markdown configuration and `content.code.select`. Visible line numbers are not enabled.

## Run

Use an existing Zensical environment, or install the recorded environment with `python -m pip install -r requirements.txt`. Then run:

```console
python -m zensical serve
```

Open http://127.0.0.1:8000/ in the browser. `python -m zensical build --clean --strict` also succeeds.

## Environment

- Zensical 0.0.74; Zensical UI 0.0.41
- Python 3.11.15
- Windows build 10.0.26200, x86_64
- Microsoft Edge 156.0.4314.58 (Chromium)
- Viewport: 432 x 850 CSS pixels, device scale factor 1
- Fresh temporary browser profile, extensions disabled

`requirements.txt` records the existing installed packages. No custom CSS, JavaScript, template overrides or additional plugins are required. The repeated paragraphs only provide vertical scroll space; the sample URLs are not fetched.

## Reproduce

1. Scroll until the code sample is near the middle of the viewport.
2. Optionally scroll the code horizontally to observe that offset as well.
3. Hover over the code if needed and click **Toggle line selection** in its top-right corner.
4. Click the text of the first code line.

Observed: the URL changes to `#__codelineno-0-1`, the selected line jumps to the very top of the viewport behind the fixed header, and the code may scroll horizontally back toward the line anchor. Expected: selecting an already visible line updates the selection and shareable URL while preserving the current viewport and code offset. Opening a permalink may still legitimately scroll to its target.

The jump occurs in both desktop rendering and mobile emulation. In the tested layout, page scrollY changed from 798 to 1158 (360 px); the selected line moved from y=360 to y=0; code scrollLeft changed from 120 to 16. Toggling the mode alone did not move the page.

The configuration does not enable instant navigation, anchor tracking, custom scripts or styles.
